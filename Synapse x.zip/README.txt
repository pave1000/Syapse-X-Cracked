Welcome to Synapse! We are glad to have you here.

To start, run Synapse Launcher.exe.

If you need any help, you can contact our support team at discord.gg/hating

Enjoy!

Cracked/Made by pave#1000